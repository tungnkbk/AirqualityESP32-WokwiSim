#include "wokwi-api.h"
#include <stdio.h>
#include <stdlib.h>

// Struct to represent the state of the chip (sensor)
typedef struct {
  pin_t pin_ao;           // Analog output pin for gas concentration
  pin_t pin_do;           // Digital output pin to indicate threshold exceeded
  pin_t pin_vcc;          // Input pin for power (VCC)
  pin_t pin_gnd;          // Input pin for ground (GND)
  uint32_t gas_attr;      // Attribute for gas concentration (user-adjustable)
  uint32_t threshold_attr; // Attribute for threshold value (user-adjustable)
} chip_state_t;

// Forward declaration for the timer event callback function
static void chip_timer_event(void *user_data);

// Initialization function, called when the simulation starts
void chip_init(void) {
  // Allocate memory for the chip state and initialize it
  chip_state_t *chip = malloc(sizeof(chip_state_t));
  
  // Initialize pins
  chip->pin_ao = pin_init("AO", ANALOG); // Analog output pin for gas concentration
  chip->pin_do = pin_init("DO", OUTPUT_LOW); // Digital output pin, initially LOW
  chip->pin_vcc = pin_init("VCC", INPUT_PULLDOWN); // Input pin with pull-down resistor
  chip->pin_gnd = pin_init("GND", INPUT_PULLUP);   // Input pin with pull-up resistor

  // Initialize attributes
  chip->gas_attr = attr_init("gas", 5);         // Default gas concentration
  chip->threshold_attr = attr_init("threshold", 20); // Default threshold

  // Configure and start a timer to periodically check sensor state
  const timer_config_t timer_config = {
    .callback = chip_timer_event, // Function to call on timer events
    .user_data = chip,            // Pass the chip state as user data
  };
  timer_t timer_id = timer_init(&timer_config); // Create a timer
  timer_start(timer_id, 1000, true);            // Start timer with 1-second intervals
}

// Timer callback function, executed at regular intervals
void chip_timer_event(void *user_data) {
  // Cast user data to the chip state
  chip_state_t *chip = (chip_state_t*)user_data;

  // Read gas concentration and threshold values, convert to voltage (0–5V range)
  float voltage = (attr_read_float(chip->gas_attr)) * 5.0 / 100;
  float threshold_v = (attr_read_float(chip->threshold_attr)) * 5.0 / 100;

  // Check if the sensor is powered (VCC is HIGH, GND is LOW)
  if (pin_read(chip->pin_vcc) && !pin_read(chip->pin_gnd)) {
    // Write the gas concentration as an analog voltage to the AO pin
    pin_dac_write(chip->pin_ao, voltage);

    // Compare the gas concentration with the threshold
    if (voltage > threshold_v) {
      // If concentration exceeds the threshold, set DO pin HIGH
      pin_write(chip->pin_do, HIGH);
    } else {
      // Otherwise, set DO pin LOW
      pin_write(chip->pin_do, LOW);
    }
  }
}
