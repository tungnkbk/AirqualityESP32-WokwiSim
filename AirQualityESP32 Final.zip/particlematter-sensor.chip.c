// #include "wokwi-api.h"
// #include <stdio.h>
// #include <stdlib.h>

// // Struct to store sensor state
// typedef struct {
//   pin_t pin_pm25_out;  // Analog output for PM2.5
//   pin_t pin_pm5_out;   // Analog output for PM5
//   pin_t pin_pm10_out;  // Analog output for PM10
//   pin_t pin_vcc;       // Power (VCC)
//   pin_t pin_gnd;       // Ground (GND)
//   uint32_t pm25_attr;  // Particulate Matter (PM2.5) concentration
//   uint32_t pm5_attr;   // Particulate Matter (PM5) concentration
//   uint32_t pm10_attr;  // Particulate Matter (PM10) concentration
// } chip_data_t;

// static void pm_sensor_timer_event(void *user_data);

// // void chip_timer_callback(void *data) {
// //   chip_data_t *chip_data = (chip_data_t*)data;
// //   int ppm = attr_read(chip_data->ppm);
// //   printf("%d\n", ppm);
  
// //   // Simulate converting TDS value to voltage
// //   float volts = ppm *5.0/ 1000;
  
// //   printf("%d\n", ppm);
// //   printf("%f\n", volts);
// //   // Send the correct voltage on the out pin
// //   pin_dac_write(chip_data->pin, volts);
// // }
// void chip_init(void) {
//   chip_data_t *sensor = (chip_data_t*)malloc(sizeof(chip_data_t));
  
//   // Initialize analog output pins
//   sensor->pin_pm25_out = pin_init("2.5OUT", ANALOG);
//   sensor->pin_pm5_out = pin_init("5OUT", ANALOG);
//   sensor->pin_pm10_out = pin_init("10OUT", ANALOG);
  
//   // Initialize power pins
//   sensor->pin_vcc = pin_init("VCC", INPUT_PULLDOWN);
//   sensor->pin_gnd = pin_init("GND", INPUT_PULLUP);
  
//   // Initialize attributes for particulate matter concentrations
//   sensor->pm25_attr = attr_init("pm25", 330);  // Initial PM2.5 concentration
//   sensor->pm5_attr = attr_init("pm5", 120);   // Initial PM5 concentration
//   sensor->pm10_attr = attr_init("pm10", 440); // Initial PM10 concentration
  
//   // Set up a periodic timer for simulation
//   const timer_config_t timer_config = {
//     .callback = pm_sensor_timer_event,
//     .user_data = sensor,
//   };
//   timer_t timer_id = timer_init(&timer_config);
//   timer_start(timer_id, 1000, true);  // Trigger every 1 second
// }

// void pm_sensor_timer_event(void *user_data) {
//   chip_data_t *sensor = (chip_data_t *)user_data;
  
//   // Read PM concentrations from attributes
//   float pm25_voltage = (attr_read_float(sensor->pm25_attr)) * 5.0 / 100;
//   float pm5_voltage = (attr_read_float(sensor->pm5_attr)) * 5.0 / 100;
//   float pm10_voltage = (attr_read_float(sensor->pm10_attr)) * 5.0 / 100;
  
//   // Ensure the sensor is powered
//   //if (pin_read(sensor->pin_vcc) && !pin_read(sensor->pin_gnd)) {
//   if (1) {
//     // Write analog outputs corresponding to PM concentrations
//     pin_dac_write(sensor->pin_pm25_out, pm25_voltage);
//     pin_dac_write(sensor->pin_pm5_out, pm5_voltage);
//     pin_dac_write(sensor->pin_pm10_out, pm10_voltage);
//   }
// }
#include "wokwi-api.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>  // Include math library for rounding

// Struct to store sensor state
typedef struct {
  pin_t pin_pm25_out;  // Analog output for PM2.5
  pin_t pin_pm5_out;   // Analog output for PM5
  pin_t pin_pm10_out;  // Analog output for PM10
  pin_t pin_vcc;       // Power (VCC)
  pin_t pin_gnd;       // Ground (GND)
  uint32_t pm25_attr;  // Particulate Matter (PM2.5) concentration
  uint32_t pm5_attr;   // Particulate Matter (PM5) concentration
  uint32_t pm10_attr;  // Particulate Matter (PM10) concentration
} chip_data_t;

// static void pm_sensor_timer_event(void *user_data);

// void chip_init(void) {
//   chip_data_t *sensor = (chip_data_t*)malloc(sizeof(chip_data_t));
  
//   // Initialize analog output pins
//   sensor->pin_pm25_out = pin_init("2.5OUT", ANALOG);
//   sensor->pin_pm5_out = pin_init("5OUT", ANALOG);
//   sensor->pin_pm10_out = pin_init("10OUT", ANALOG);
  
//   // Initialize power pins
//   sensor->pin_vcc = pin_init("VCC", INPUT_PULLDOWN);
//   sensor->pin_gnd = pin_init("GND", INPUT_PULLUP);
  
//   // Initialize attributes for particulate matter concentrations (integers)
//   sensor->pm25_attr = attr_init("pm25", 33);  // Initial PM2.5 concentration (33 μg/m³)
//   sensor->pm5_attr = attr_init("pm5", 12);   // Initial PM5 concentration (12 μg/m³)
//   sensor->pm10_attr = attr_init("pm10", 44); // Initial PM10 concentration (44 μg/m³)
  
//   // Set up a periodic timer for simulation
//   const timer_config_t timer_config = {
//     .callback = pm_sensor_timer_event,
//     .user_data = sensor,
//   };
//   timer_t timer_id = timer_init(&timer_config);
//   timer_start(timer_id, 1000, true);  // Trigger every 1 second
// }
void chip_timer_callback(void *data) {
  chip_data_t *chip_data = (chip_data_t*)data;
  
  // Simulate changing concentrations for PM2.5, PM5, and PM10
  // For the purpose of simulation, you can modify these values here
  // For example, you could use random values or simulate a gradual increase or decrease.
  
  int pm25_value = (rand() % 100); // Random value between 0 and 100
  int pm5_value = (rand() % 100);  // Random value between 0 and 100
  int pm10_value = (rand() % 100); // Random value between 0 and 100
  
  // Update the attributes with new values
  chip_data->pm25_attr= pm25_value;
  chip_data->pm5_attr= pm5_value;
  chip_data->pm10_attr= pm10_value;

  // Now read the updated concentrations
  float pm25_voltage = (pm25_value * 5.0) / 100;
  float pm5_voltage = (pm5_value * 5.0) / 100;
  float pm10_voltage = (pm10_value * 5.0) / 100;

  // Convert to integer voltage values (round and write to the DAC)
  // int pm25_voltage_int = (int)(pm25_voltage * 100); // Convert to integer DAC value
  // int pm5_voltage_int = (int)(pm5_voltage * 100);   // Convert to integer DAC value
  // int pm10_voltage_int = (int)(pm10_voltage * 100);  // Convert to integer DAC value

  // Write analog outputs corresponding to PM concentrations
  pin_dac_write(chip_data->pin_pm25_out, pm25_voltage);
  pin_dac_write(chip_data->pin_pm5_out, pm5_voltage);
  pin_dac_write(chip_data->pin_pm10_out, pm10_voltage);
}


void chip_init() {
  chip_data_t *data = (chip_data_t*)malloc(sizeof(chip_data_t));
  data->pm25_attr = attr_init("pm25", 33);  // Initial PM2.5 concentration (33 μg/m³)
  data->pm5_attr = attr_init("pm5", 12);   // Initial PM5 concentration (12 μg/m³)
  data->pm10_attr = attr_init("pm10", 44); // Initial PM10 concentration (44 μg/m³)
  
  data->pin_pm25_out = pin_init("2.5OUT", ANALOG);
  data->pin_pm5_out = pin_init("5OUT", ANALOG);
  data->pin_pm10_out = pin_init("10OUT", ANALOG);
  // TODO: Initialize the chip, set up IO pins, create timers, etc.
  
  const timer_config_t config = {
    .callback = chip_timer_callback,
    .user_data = data,
  };

  timer_t timer_id = timer_init(&config);
  timer_start(timer_id, 1000, true); 


}


// void pm_sensor_timer_event(void *user_data) {
//   chip_data_t *sensor = (chip_data_t *)user_data;
  
//   // Read PM concentrations from attributes (as integers)
//   int pm25_concentration = attr_read(sensor->pm25_attr);
//   int pm5_concentration = attr_read(sensor->pm5_attr);
//   int pm10_concentration = attr_read(sensor->pm10_attr);

//   // Convert concentrations (0-100) to voltages (0-5V range) and round to nearest integer
//   int pm25_voltage = (int)round((pm25_concentration * 5.0) / 100);
//   int pm5_voltage = (int)round((pm5_concentration * 5.0) / 100);
//   int pm10_voltage = (int)round((pm10_concentration * 5.0) / 100);

//   // Ensure the sensor is powered
//   if (pin_read(sensor->pin_vcc) && !pin_read(sensor->pin_gnd)) {
//     // Write analog outputs corresponding to PM concentrations (in integer format)
//     pin_dac_write(sensor->pin_pm25_out, pm25_voltage);
//     pin_dac_write(sensor->pin_pm5_out, pm5_voltage);
//     pin_dac_write(sensor->pin_pm10_out, pm10_voltage);
//   }
// }


